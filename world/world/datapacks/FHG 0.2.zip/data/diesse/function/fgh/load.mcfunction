##
 # load.mcfunction
 # 
 #
 # Created by .
##
scoreboard objectives add fgh.config dummy
scoreboard players set &speed fgh.config 1