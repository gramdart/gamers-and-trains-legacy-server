##
 # main.mcfunction
 # fgh
 #
 # Created by diesse.
##
execute if score &speed fgh.config matches 1 as @e[type=happy_ghast] if predicate diesse:is_vehicle run attribute @s minecraft:flying_speed base set 0.075
execute if score &speed fgh.config matches 2 as @e[type=happy_ghast] if predicate diesse:is_vehicle run attribute @s minecraft:flying_speed base set 0.1
execute if score &speed fgh.config matches 3 as @e[type=happy_ghast] if predicate diesse:is_vehicle run attribute @s minecraft:flying_speed base set 0.125
execute as @e[type=happy_ghast] unless predicate diesse:is_vehicle run attribute @s minecraft:flying_speed base set 0.05